const { getPool, ensureInit } = require('../lib/db');
const { BUSES, tsagToMinutes, zovlomj } = require('../lib/zovlomj');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  const p = getPool();
  if (!p) return res.status(503).json({ ok: false, aldaa: 'Датабаз тохируулагдаагүй.' });

  const b = req.body || {};
  const anonId = String(b.anonId || '').trim().slice(0, 64);
  const garah = String(b.garahBus || '').trim();
  const ochih = String(b.ochihBus || '').trim();
  const tsag = String(b.tsag || '').trim().slice(0, 5);
  let davtamj = String(b.davtamj || 'ajliin_odor');

  if (!anonId || !BUSES.has(garah) || !BUSES.has(ochih))
    return res.status(400).json({ ok: false, aldaa: 'Бүс, anonId буруу байна.' });
  if (tsagToMinutes(tsag) === null)
    return res.status(400).json({ ok: false, aldaa: 'Цаг HH:MM хэлбэртэй байх ёстой.' });
  if (!['odor_bur', 'ajliin_odor', 'neg_udaa'].includes(davtamj)) davtamj = 'ajliin_odor';

  try {
    await ensureInit(p);
    await p.query(
      'INSERT INTO zorilgo (anon_id, garah_bus, ochih_bus, tsag, davtamj) VALUES ($1,$2,$3,$4,$5)',
      [anonId, garah, ochih, tsag, davtamj]
    );
    const r = await p.query(
      'SELECT tsag FROM zorilgo WHERE garah_bus = $1 AND ochih_bus = $2',
      [garah, ochih]
    );
    res.json({ ok: true, ...zovlomj(r.rows, tsag) });
  } catch (e) {
    console.error('zorilgo aldaa:', e.message);
    res.status(500).json({ ok: false, aldaa: 'Серверийн алдаа.' });
  }
};
