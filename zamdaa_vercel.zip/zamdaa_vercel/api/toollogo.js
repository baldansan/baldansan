const { getPool, ensureInit } = require('../lib/db');

module.exports = async (_req, res) => {
  const p = getPool();
  if (!p) return res.json({ burtgel: 0, bair: 0, ilgeemj: 0, shat: 500 });
  try {
    await ensureInit(p);
    const r = await p.query(`
      SELECT
        (SELECT COUNT(*) FROM burtgel)::int AS burtgel,
        (SELECT COUNT(DISTINCT duureg || '|' || bair) FROM burtgel)::int AS bair,
        (SELECT COALESCE(v, '0') FROM tohirgoo WHERE k = 'ilgeemj') AS ilgeemj
    `);
    const row = r.rows[0];
    const ilgeemj = Number(row.ilgeemj) || 0;
    const shat = ilgeemj >= 1000 ? 1500 : ilgeemj >= 500 ? 1000 : 500;
    res.setHeader('Cache-Control', 's-maxage=30, stale-while-revalidate=60');
    res.json({ burtgel: row.burtgel, bair: row.bair, ilgeemj, shat });
  } catch (e) {
    console.error('toollogo aldaa:', e.message);
    res.json({ burtgel: 0, bair: 0, ilgeemj: 0, shat: 500 });
  }
};
