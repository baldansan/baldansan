const { getPool, ensureInit } = require('../lib/db');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false, aldaa: 'POST хүсэлт илгээнэ үү.' });

  const p = getPool();
  if (!p) return res.status(503).json({ ok: false, aldaa: 'Датабаз тохируулагдаагүй байна (POSTGRES_URL).' });

  const b = req.body || {};
  const ner = String(b.ner || '').trim().slice(0, 100);
  const utas = String(b.utas || '').replace(/\D/g, '');
  const duureg = String(b.duureg || '').trim().slice(0, 50);
  const bair = String(b.bair || '').trim().slice(0, 200);

  if (!ner || !duureg || !bair) return res.status(400).json({ ok: false, aldaa: 'Нэр, дүүрэг, байрны хаяг заавал.' });
  if (!/^[0-9]{8}$/.test(utas)) return res.status(400).json({ ok: false, aldaa: 'Утасны дугаар 8 оронтой байх ёстой.' });
  if (!b.zovshoorol) return res.status(400).json({ ok: false, aldaa: 'Нууцлалын зөвшөөрөл шаардлагатай.' });

  try {
    await ensureInit(p);
    const dup = await p.query('SELECT id FROM burtgel WHERE utas = $1 AND bair = $2 LIMIT 1', [utas, bair]);
    if (dup.rows.length) return res.json({ ok: true, davhardal: true });

    await p.query(
      `INSERT INTO burtgel (ner, utas, duureg, bair, orts, soh_ner, jijuurtei, hurgelt_sonirhol, zovshoorol, ognoo, esh)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,true,$9,$10)`,
      [
        ner, utas, duureg, bair,
        String(b.orts || '').trim().slice(0, 50),
        String(b.sohNer || '').trim().slice(0, 100),
        String(b.jijuurtei || '').trim().slice(0, 50),
        !!b.hurgeltSonirhol,
        b.ognoo || new Date().toISOString(),
        String(b.esh || 'web').slice(0, 10),
      ]
    );
    res.json({ ok: true });
  } catch (e) {
    console.error('burtgel aldaa:', e.message);
    res.status(500).json({ ok: false, aldaa: 'Серверийн алдаа — дахин оролдоно уу.' });
  }
};
