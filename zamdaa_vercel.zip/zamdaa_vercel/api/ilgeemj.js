const { getPool, ensureInit } = require('../lib/db');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  if (!process.env.ADMIN_TOKEN || req.query.token !== process.env.ADMIN_TOKEN) return res.status(403).json({ ok: false });

  const n = Number((req.body || {}).ilgeemj);
  if (!Number.isFinite(n) || n < 0) return res.status(400).json({ ok: false, aldaa: 'ilgeemj тоо байх ёстой.' });

  const p = getPool();
  if (!p) return res.status(503).json({ ok: false, aldaa: 'Датабаз тохируулагдаагүй.' });
  try {
    await ensureInit(p);
    await p.query(`INSERT INTO tohirgoo (k, v) VALUES ('ilgeemj', $1) ON CONFLICT (k) DO UPDATE SET v = $1`, [String(Math.floor(n))]);
    res.json({ ok: true, ilgeemj: Math.floor(n) });
  } catch (e) {
    console.error('ilgeemj aldaa:', e.message);
    res.status(500).json({ ok: false });
  }
};
