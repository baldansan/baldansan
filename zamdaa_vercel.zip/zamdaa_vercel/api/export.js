const { getPool, ensureInit } = require('../lib/db');

module.exports = async (req, res) => {
  if (!process.env.ADMIN_TOKEN || req.query.token !== process.env.ADMIN_TOKEN) return res.status(403).json({ ok: false });

  const p = getPool();
  if (!p) return res.status(503).json({ ok: false, aldaa: 'Датабаз тохируулагдаагүй.' });
  try {
    await ensureInit(p);
    const r = await p.query('SELECT * FROM burtgel ORDER BY id');
    const esc = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const head = 'id,ner,utas,duureg,bair,orts,soh_ner,jijuurtei,hurgelt_sonirhol,zovshoorol,ognoo,esh';
    const body = r.rows.map(x =>
      [x.id, x.ner, x.utas, x.duureg, x.bair, x.orts, x.soh_ner, x.jijuurtei, x.hurgelt_sonirhol, x.zovshoorol, x.ognoo, x.esh].map(esc).join(',')
    ).join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="zamdaa_burtgel.csv"');
    res.send('﻿' + head + '\n' + body);
  } catch (e) {
    console.error('export aldaa:', e.message);
    res.status(500).json({ ok: false });
  }
};
