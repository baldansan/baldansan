const { getPool, ensureInit } = require('../lib/db');

// Нууцлалын амлалт: хэрэглэгч anon_id-гаараа бүх зорилгын датагаа устгуулна.
module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  const p = getPool();
  if (!p) return res.status(503).json({ ok: false });

  const anonId = String((req.body || {}).anonId || '').trim().slice(0, 64);
  if (!anonId) return res.status(400).json({ ok: false });

  try {
    await ensureInit(p);
    const r = await p.query('DELETE FROM zorilgo WHERE anon_id = $1', [anonId]);
    res.json({ ok: true, ustgasan: r.rowCount });
  } catch (e) {
    console.error('ustgah aldaa:', e.message);
    res.status(500).json({ ok: false });
  }
};
