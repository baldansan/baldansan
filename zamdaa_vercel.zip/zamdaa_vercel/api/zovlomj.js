const { getPool, ensureInit } = require('../lib/db');
const { BUSES, zovlomj } = require('../lib/zovlomj');

module.exports = async (req, res) => {
  const p = getPool();
  const garah = String(req.query.garahBus || '');
  const ochih = String(req.query.ochihBus || '');
  const tsag = String(req.query.tsag || '');
  if (!p || !BUSES.has(garah) || !BUSES.has(ochih))
    return res.json({ zovlomj: '', medregch: 0 });
  try {
    await ensureInit(p);
    const r = await p.query(
      'SELECT tsag FROM zorilgo WHERE garah_bus = $1 AND ochih_bus = $2',
      [garah, ochih]
    );
    res.json(zovlomj(r.rows, tsag));
  } catch (e) {
    console.error('zovlomj aldaa:', e.message);
    res.json({ zovlomj: '', medregch: 0 });
  }
};
