# zamdaa — Vercel дээр гаргах заавар

## Бүтэц

- `index.html` — лендинг (API-тай холбогдсон)
- `api/burtgel.js` — бүртгэл хадгалах (POST)
- `api/toollogo.js` — тоолуур (GET)
- `api/ilgeemj.js` — шөнийн илгээмжийн тоо шинэчлэх (админ, POST + ?token=)
- `api/export.js` — бүх бүртгэл CSV татах (админ, GET + ?token=)
- `api/zorilgo.js`, `api/zovlomj.js`, `api/ustgah.js` — зорилгын дата (нэргүй), зөвлөмж, устгах
- `lib/db.js`, `lib/zovlomj.js` — Postgres холболт + зөвлөмжийн эвристик

## Гаргах 2 арга

### Арга 1 — GitHub-гүй, хамгийн хурдан (Vercel CLI)

```bash
# Компьютер дээрээ (Node суусан байх):
npm i -g vercel
cd zamdaa_vercel        # энэ хавтас руу орно
vercel login            # өөрийн Vercel акаунтаараа
vercel                  # асуултуудад Enter дараад л deploy болно
vercel --prod           # production болгох
```

### Арга 2 — GitHub-ээр (дараа автомат deploy болдгоороо давуу)

1. github.com дээрээ шинэ repo үүсгэ (жишээ нь `zamdaa`)
2. Энэ хавтасны файлуудыг оруул: repo нээгээд **Add file → Upload files** — бүх файлаа чирж оруулаад Commit (эсвэл `git push`-ээр)
3. vercel.com → **Add New → Project** → GitHub repo-гоо сонго → Deploy

## Датабаз холбох (бүртгэл ХАДГАЛАГДАХЫН тулд заавал)

1. Vercel project → **Storage** таб → **Create Database** → **Neon (Postgres)** → үнэгүй план → өөрийн project-той холбо
2. Холбоход `POSTGRES_URL` орчны хувьсагч автоматаар тавигдана
3. **Settings → Environment Variables** дээр нэмж `ADMIN_TOKEN` = өөрийн нууц үг (export/ilgeemj цэгүүдэд хэрэглэнэ)
4. Дахин deploy (**Deployments → Redeploy**)

Датабазгүй байхад: хуудас нээгдэнэ, тоолуур 0 харагдана, форм илгээхэд «Датабаз тохируулагдаагүй» гэсэн алдаа өгнө — эвдрэхгүй.

## Шалгах

- `https://<тань-project>.vercel.app/` — лендинг нээгдэнэ
- `https://<тань-project>.vercel.app/api/toollogo` — `{"burtgel":0,...}` JSON харагдана
- Формоор нэг бүртгэл өгөөд toollogo дахин нээхэд тоо нэмэгдсэн байна
- `.../api/export.csv?token=НУУЦҮГ` — CSV татагдана (Excel-д нээгдэнэ)

## Дараа нь zamdaa.mn домэйн холбох

Домэйноо авсны дараа: Vercel project → **Settings → Domains** → `zamdaa.mn` нэмэх → зааврын дагуу DNS (A/CNAME) бичлэгийг домэйны бүртгэгч дээрээ тавих. Тусдаа сервер огт хэрэггүй — Vercel үнэгүй планаар энэ ачааллыг даана.

## Санамжууд

- Утасны дугаар хадгалагддаг тул `ADMIN_TOKEN`-оо хэнтэй ч хуваалцахгүй
- Нууцлалын бодлогын текстийг хуульчаар батлуулаад формыг олон нийтэд нээнэ
- Балжмаа аппаас мөн энэ API руу бичиж болно (`esh: "app"` талбар нэмээд илгээхэд болно)
